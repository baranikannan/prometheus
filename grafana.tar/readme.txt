This script is to install Prometheus, Graphite and Grafana.

Prometheus has three compnentes running Server, Node and bridge where bridge runs to send data from neode to Graphite.

Run seetup.sh to start the script.

Requires virtualbox, virtual box extensions and packer.

